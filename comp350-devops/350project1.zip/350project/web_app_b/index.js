const express = require('express');
const bodyParser = require('body-parser');
const { Pool } = require('pg');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

app.get('/', (req, res) => {
  res.send(`
    <form action="/" method="post">
      First Name: <input type="text" name="first_name"><br>
      Last Name: <input type="text" name="last_name"><br>
      <input type="submit" value="Submit">
    </form>
  `);
});

app.post('/', async (req, res) => {
  const { first_name, last_name } = req.body;
  try {
    const result = await pool.query('SELECT * FROM users WHERE first_name = $1 AND last_name = $2', [first_name, last_name]);
    if (result.rows.length > 0) {
      res.send(`
        <p>Name already exists</p>
        <a href="/">Enter a new record</a>
      `);
    } else {
      await pool.query('INSERT INTO users (first_name, last_name) VALUES ($1, $2)', [first_name, last_name]);
      res.send(`
        <p>Record added successfully</p>
        <a href="/">Enter a new record</a>
      `);
    }
  } catch (err) {
    console.error(err);
    res.send('Error occurred');
  }
});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});
