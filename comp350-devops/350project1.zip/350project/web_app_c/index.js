const express = require('express');
const { Pool } = require('pg');

const app = express();

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
});

app.get('/', async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM users');
    const users = result.rows;
    let html = '<ul>';
    users.forEach(user => {
      html += `<li>${user.id}: ${user.first_name} ${user.last_name} <a href="/delete/${user.id}">x</a></li>`;
    });
    html += '</ul>';
    html += `<p>Total records: ${users.length}</p>`;
    html += '<a href="/">Refresh</a>';
    res.send(html);
  } catch (err) {
    console.error(err);
    res.send('Error occurred');
  }
});

app.get('/delete/:id', async (req, res) => {
  const id = req.params.id;
  try {
    await pool.query('DELETE FROM users WHERE id = $1', [id]);
    res.redirect('/');
  } catch (err) {
    console.error(err);
    res.send('Error occurred');
  }
});

app.listen(3000, () => {
  console.log('Server is running on port 3000');
});
